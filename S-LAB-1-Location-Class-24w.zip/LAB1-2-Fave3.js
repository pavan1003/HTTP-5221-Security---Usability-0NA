﻿/*LAB 1-2: JAVASCRIPT CLASSES*/
//FAVE FRIEND CLASS



window.onload = function(){
	var faveThree = [];//FAVE 3 ARRAY



}//END OF onload FUNCTION